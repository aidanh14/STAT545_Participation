#' @title Square the input
#' @param x Vector of numerics
#' @return The vector x, squared.
#' @export
## Note: need to run `document()` function from roxygen2 (part of `devtools` package) to generate the documentation files.
square <-  function(x) x^2
